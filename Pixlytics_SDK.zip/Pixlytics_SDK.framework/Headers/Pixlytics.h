//
//  Pixlytics.h
//  Pixlytics-SDK
//
//  Created by Bertrand VILLAIN on 25/03/2019.
//  Copyright © 2019 Wassa. All rights reserved.
//

#ifndef Pixlytics_h
#define Pixlytics_h

//#include <stdio.h>
#include "LicenseKeyStatus.h"
#include "RecognitionSession.h"

@interface Pixlytics : NSObject

/*- (instancetype)initWithLicense:(NSString*) licenseKey;
- (LicenseKeyStatus)getLicenseStatus;
- (void)updateLicense:(NSString*) licenseKey;*/

@end

#endif
